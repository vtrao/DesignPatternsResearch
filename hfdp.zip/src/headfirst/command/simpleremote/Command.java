package headfirst.command.simpleremote;

public interface Command {
	public void execute();
}

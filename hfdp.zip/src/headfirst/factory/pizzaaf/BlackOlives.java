package headfirst.factory.pizzaaf;

public class BlackOlives implements Veggies {

	public String toString() {
		return "Black Olives";
	}
}
